"""Задачи на NumPy."""

import matplotlib.pyplot as plt
import numpy as np
from grader_contracts.numpy_tasks import (
    BinarizeInput, ChessInput, EllipseInput, MatrixInput, MatrixStatistics,
    MatrixVectorBatchInput, OneHotInput, RandomMatrixInput, RectangleInput,
    TimeSeriesInput, TimeSeriesStatistics,
)


def sum_prod(data: MatrixVectorBatchInput) -> np.ndarray:
    matrices, vectors = data.matrices, data.vectors
    result = np.zeros_like(vectors[0], dtype=float)
    for i in range(len(matrices)):
        result = result + np.dot(matrices[i], vectors[i])
    return result

def binarize(data: BinarizeInput) -> np.ndarray:
    matrix, threshold = data.matrix, data.threshold
    result = np.zeros(matrix.shape, dtype=int)
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            if matrix[i, j] > threshold:
                result[i, j] = 1
    return result


def unique_rows(data: MatrixInput) -> list[list[float]]:
    matrix = data.matrix
    result = []
    for row in matrix:
        values = []
        for value in row:
            if value not in values:
                values.append(value)
        result.append(values)
    return result


def unique_columns(data: MatrixInput) -> list[list[float]]:
    matrix = data.matrix
    result = []
    for j in range(matrix.shape[1]):
        values = []
        for i in range(matrix.shape[0]):
            value = matrix[i, j]
            if value not in values:
                values.append(value)
        result.append(values)
    return result

def plot_statistics(statistics):
    # Гистограмма средних значений по строкам.
    plt.figure()
    plt.hist(statistics.row_means)
    plt.title("Средние значения строк")
    plt.xlabel("Значение")
    plt.ylabel("Количество")

    # Гистограмма средних значений по столбцам.
    plt.figure()
    plt.hist(statistics.column_means)
    plt.title("Средние значения столбцов")
    plt.xlabel("Значение")
    plt.ylabel("Количество")
    plt.show()

def matrix_statistics(data: RandomMatrixInput) -> MatrixStatistics:
    rows, columns, mean, std, seed = data.rows, data.columns, data.mean, data.std, data.seed
    generator = np.random.default_rng(seed)
    matrix = generator.normal(mean, std, (rows, columns))
    row_means = np.mean(matrix, axis=1)
    column_means = np.mean(matrix, axis=0)
    row_variances = np.var(matrix, axis=1)
    column_variances = np.var(matrix, axis=0)
    return MatrixStatistics(matrix, row_means, column_means, row_variances, column_variances)


def chess(data: ChessInput) -> np.ndarray:
    rows, columns, first, second = data.rows, data.columns, data.first, data.second
    result = np.zeros((rows, columns))
    for i in range(rows):
        for j in range(columns):
            if (i + j) % 2 == 0:
                result[i, j] = first
            else:
                result[i, j] = second
    return result


def draw_rectangle(data: RectangleInput) -> np.ndarray:
    width, height = data.width, data.height
    image_height, image_width = data.image_height, data.image_width
    shape_color, background_color = data.shape_color, data.background_color
    image = np.zeros((image_height, image_width, 3), dtype=np.uint8)
    image[:] = background_color
    x_start = (image_width - width) // 2
    y_start = (image_height - height) // 2
    x_end = x_start + width
    y_end = y_start + height
    image[y_start:y_end, x_start:x_end] = shape_color
    return image

def draw_ellipse(data: EllipseInput) -> np.ndarray:
    semi_axis_x, semi_axis_y = data.semi_axis_x, data.semi_axis_y
    image_height, image_width = data.image_height, data.image_width
    shape_color, background_color = data.shape_color, data.background_color
    image = np.zeros((image_height, image_width, 3), dtype=np.uint8)
    image[:] = background_color
    center_x = (image_width - 1) / 2
    center_y = (image_height - 1) / 2
    for y in range(image_height):
        for x in range(image_width):
            part_x = ((x - center_x) ** 2) / (semi_axis_x ** 2)
            part_y = ((y - center_y) ** 2) / (semi_axis_y ** 2)
            if part_x + part_y <= 1:
                image[y, x] = shape_color
    return image


def analyze_time_series(data: TimeSeriesInput) -> TimeSeriesStatistics:
    values, window = data.values, data.window
    values = np.array(values, dtype=float)
    mean = float(np.mean(values))
    variance = float(np.var(values))
    std = float(np.std(values))
    maxima = []
    minima = []
    for i in range(1, len(values) - 1):
        if values[i] > values[i - 1] and values[i] > values[i + 1]:
            maxima.append(i)
        if values[i] < values[i - 1] and values[i] < values[i + 1]:
            minima.append(i)
    moving_average = []
    for i in range(len(values) - window + 1):
        total = 0
        for j in range(window):
            total += values[i + j]
        moving_average.append(total / window)
    return TimeSeriesStatistics(mean, variance, std, np.array(maxima), np.array(minima), np.array(moving_average))


def one_hot(data: OneHotInput) -> np.ndarray:
    labels, class_count = data.labels, data.class_count
    labels = np.array(labels, dtype=int)
    if class_count is None:
        if len(labels) == 0:
            class_count = 0
        else:
            class_count = int(np.max(labels)) + 1
    result = np.zeros((len(labels), class_count), dtype=int)
    for i in range(len(labels)):
        if labels[i] < class_count:
            result[i, labels[i]] = 1
    return result
