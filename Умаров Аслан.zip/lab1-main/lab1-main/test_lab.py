""" Проверки функций."""

import unittest
import numpy as np

from grader_contracts.python_basics import PositiveIntegerInput, TextInput, VectorPairInput
from grader_contracts.numpy_tasks import (
    BinarizeInput, ChessInput, EllipseInput, MatrixInput, MatrixVectorBatchInput,
    OneHotInput, RandomMatrixInput, RectangleInput, TimeSeriesInput,
)
from python_basics import (
    count_vowels, has_unique_characters, count_one_bits,
    multiplicative_persistence, mse, prime_factorization, pyramid,
    is_balanced_number,
)
from numpy_tasks import (
    sum_prod, binarize, unique_rows, unique_columns, matrix_statistics,
    chess, draw_rectangle, draw_ellipse, analyze_time_series, one_hot,
)


class PythonBasicsTests(unittest.TestCase):
    def test_count_vowels(self):
        self.assertEqual(count_vowels(TextInput("Hello")), 2)
        self.assertEqual(count_vowels(TextInput("AEIOU")), 5)
        self.assertEqual(count_vowels(TextInput("xyz")), 0)

    def test_unique_characters(self):
        self.assertTrue(has_unique_characters(TextInput("abc")))
        self.assertFalse(has_unique_characters(TextInput("hello")))
        self.assertTrue(has_unique_characters(TextInput("")))

    def test_one_bits(self):
        self.assertEqual(count_one_bits(PositiveIntegerInput(7)), 3)
        self.assertEqual(count_one_bits(PositiveIntegerInput(8)), 1)

    def test_persistence(self):
        self.assertEqual(multiplicative_persistence(PositiveIntegerInput(39)), 3)
        self.assertEqual(multiplicative_persistence(PositiveIntegerInput(4)), 0)

    def test_mse(self):
        self.assertEqual(mse(VectorPairInput([1, 2], [2, 4])), 2.5)

    def test_factorization(self):
        self.assertEqual(prime_factorization(PositiveIntegerInput(12)), "(2**2)(3)")
        self.assertEqual(prime_factorization(PositiveIntegerInput(1)), "")

    def test_pyramid(self):
        self.assertEqual(pyramid(PositiveIntegerInput(14)), 3)
        self.assertEqual(pyramid(PositiveIntegerInput(6)), "It is impossible")

    def test_balanced(self):
        self.assertTrue(is_balanced_number(PositiveIntegerInput(1234006)))
        self.assertFalse(is_balanced_number(PositiveIntegerInput(123456)))


class NumpyTests(unittest.TestCase):
    def test_sum_prod(self):
        matrices = np.array([[[1, 0], [0, 1]], [[2, 0], [0, 2]]])
        vectors = np.array([[[1], [2]], [[3], [4]]])
        np.testing.assert_array_equal(sum_prod(MatrixVectorBatchInput(matrices, vectors)), [[7], [10]])

    def test_binarize(self):
        matrix = np.array([[0.2, 0.8]])
        result = binarize(BinarizeInput(matrix, 0.5))
        np.testing.assert_array_equal(result, [[0, 1]])
        np.testing.assert_array_equal(matrix, [[0.2, 0.8]])

    def test_unique(self):
        matrix = np.array([[1, 2], [1, 3]])
        self.assertEqual(unique_rows(MatrixInput(matrix)), [[1, 2], [1, 3]])
        self.assertEqual(unique_columns(MatrixInput(matrix)), [[1], [2, 3]])

    def test_statistics(self):
        result = matrix_statistics(RandomMatrixInput(2, 3, seed=10))
        self.assertEqual(result.matrix.shape, (2, 3))
        self.assertEqual(len(result.row_means), 2)
        self.assertEqual(len(result.column_variances), 3)

    def test_chess(self):
        result = chess(ChessInput(2, 3, 0, 1))
        np.testing.assert_array_equal(result, [[0, 1, 0], [1, 0, 1]])

    def test_rectangle(self):
        result = draw_rectangle(RectangleInput(2, 2, 4, 4, (255, 0, 0), (0, 0, 0)))
        self.assertEqual(result.shape, (4, 4, 3))
        np.testing.assert_array_equal(result[1, 1], [255, 0, 0])

    def test_ellipse(self):
        result = draw_ellipse(EllipseInput(1, 1, 3, 3, (255, 0, 0), (0, 0, 0)))
        self.assertEqual(result.shape, (3, 3, 3))
        np.testing.assert_array_equal(result[1, 1], [255, 0, 0])

    def test_time_series(self):
        result = analyze_time_series(TimeSeriesInput([1, 3, 1, 4, 2], 2))
        self.assertEqual(result.local_maxima_indices.tolist(), [1, 3])
        self.assertEqual(result.local_minima_indices.tolist(), [2])
        np.testing.assert_allclose(result.moving_average, [2, 2, 2.5, 3])

    def test_one_hot(self):
        result = one_hot(OneHotInput([0, 2, 1]))
        np.testing.assert_array_equal(result, [[1, 0, 0], [0, 0, 1], [0, 1, 0]])
        self.assertEqual(one_hot(OneHotInput([1], 4)).shape, (1, 4))


if __name__ == "__main__":
    unittest.main()
