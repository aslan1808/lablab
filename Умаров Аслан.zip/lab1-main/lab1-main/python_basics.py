"""Задачи на базовый Python."""

from grader_contracts.python_basics import PositiveIntegerInput, TextInput, VectorPairInput


def count_vowels(data: TextInput) -> int:
    text = data.value.lower()
    count = 0
    for letter in text:
        if letter in "aeiou":
            count += 1
    return count


def has_unique_characters(data: TextInput) -> bool:
    text = data.value
    for i in range(len(text)):
        for j in range(i + 1, len(text)):
            if text[i] == text[j]:
                return False
    return True


def count_one_bits(data: PositiveIntegerInput) -> int:
    number = data.value
    count = 0
    while number > 0:
        if number % 2 == 1:
            count += 1
        number = number // 2
    return count


def multiplicative_persistence(data: PositiveIntegerInput) -> int:
    number = data.value
    steps = 0
    while number >= 10:
        product = 1
        for digit in str(number):
            product *= int(digit)
        number = product
        steps += 1
    return steps


def mse(data: VectorPairInput) -> float:
    predicted, expected = data.predicted, data.expected
    total = 0
    for i in range(len(predicted)):
        difference = predicted[i] - expected[i]
        total += difference * difference
    return total / len(predicted)


def prime_factorization(data: PositiveIntegerInput) -> str:
    number = data.value
    if number == 1:
        return ""
    result = ""
    divisor = 2
    while number > 1:
        power = 0
        while number % divisor == 0:
            number = number // divisor
            power += 1
        if power > 0:
            if power == 1:
                result += "(" + str(divisor) + ")"
            else:
                result += "(" + str(divisor) + "**" + str(power) + ")"
        divisor += 1
    return result


def pyramid(data: PositiveIntegerInput) -> int | str:
    cube_count = data.value
    total = 0
    level = 1
    while total < cube_count:
        total += level * level
        if total == cube_count:
            return level
        level += 1
    return "It is impossible"


def is_balanced_number(data: PositiveIntegerInput) -> bool:
    digits = str(data.value)
    middle = len(digits) // 2
    if len(digits) % 2 == 0:
        left = digits[:middle - 1]
        right = digits[middle + 1:]
    else:
        left = digits[:middle]
        right = digits[middle + 1:]
    left_sum = 0
    right_sum = 0
    for digit in left:
        left_sum += int(digit)
    for digit in right:
        right_sum += int(digit)
    return left_sum == right_sum
